import serverless_sdk
sdk = serverless_sdk.SDK(
    org_id='shankargupta',
    application_name='sample-test-app',
    app_uid='ngKVhmf3ZVdlhq3fVb',
    org_uid='42a5ae49-72ae-4afd-a8c9-409c6b2dccd3',
    deployment_uid='ee479747-4bd8-42af-8806-8e09e56d7b87',
    service_name='aws-python-http-api-project',
    should_log_meta=True,
    should_compress_logs=True,
    disable_aws_spans=False,
    disable_http_spans=False,
    stage_name='dev',
    plugin_version='6.2.2',
    disable_frameworks_instrumentation=False,
    serverless_platform_stage='prod'
)
handler_wrapper_kwargs = {'function_name': 'aws-python-http-api-project-dev-get', 'timeout': 6}
try:
    user_handler = serverless_sdk.get_user_handler('handler.hello')
    handler = sdk.handler(user_handler, **handler_wrapper_kwargs)
except Exception as error:
    e = error
    def error_handler(event, context):
        raise e
    handler = sdk.handler(error_handler, **handler_wrapper_kwargs)
